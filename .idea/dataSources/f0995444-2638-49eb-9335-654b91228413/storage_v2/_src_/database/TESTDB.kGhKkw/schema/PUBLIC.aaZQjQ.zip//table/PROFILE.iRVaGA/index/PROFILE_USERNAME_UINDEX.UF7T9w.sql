create unique index PROFILE_USERNAME_UINDEX
    on PROFILE (USERNAME);

